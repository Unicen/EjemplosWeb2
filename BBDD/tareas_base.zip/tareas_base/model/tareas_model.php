<?php

class TareasModel {

  private $tareas;

  function __construct() {
      $this->tareas = array(
         ['Titulo' => 'Tarea 1', 'Descripcion' => '']
        ,['Titulo' => 'Tarea 2', 'Descripcion' => 'La tarea 2 tiene descripcion']
        ,['Titulo' => 'Tarea 3', 'Descripcion' => 'Sin comentarios']
    );
  }

  function getTareas(){
    return $this->tareas;
  }

  function agregarTarea($tarea){
    array_push($this->tareas, $tarea);
  }

  function finalizarTarea($tarea){
      unset($this->tareas[$tarea['id']]);
  }

}
?>
