<?php

class ConfigApp {

  public static $ACTION = 'action';
  public static $ACTION_DEFAULT = 'home';
  public static $ACTION_AGREGAR_TAREA = 'agregar_tarea';
  public static $ACTION_FINALIZAR_TAREA = 'finalizar_tarea';
}
 ?>
