<?php

class TareasModel {

  private $tareas;
  function __construct() {
    $this->db = new PDO('mysql:host=localhost;'
      .'dbname=web2tudai;charset=utf8'
        , 'tudai', 'tudai');

  }

  function getTareas(){
    $consulta = $this->db->prepare(
      'SELECT * FROM tarea WHERE Finalizada=0');
    $consulta->execute();
    $tareas = $consulta->fetchAll(PDO::FETCH_UNIQUE|PDO::FETCH_ASSOC);
    return $tareas;
  }

  function agregarTarea($tarea){
    $sentencia = $this->db->prepare(
      "INSERT INTO tarea(Titulo, Descripcion)"
      ."VALUES(:titulo, :descripcion)");

    $sentencia->execute(
      array(":titulo"=>$tarea['Titulo']
      ,":descripcion"=>$tarea['Descripcion']));

    return $this->db->lastInsertId();
  }

  function finalizarTarea($tarea){
    $sentencia = $this->db->prepare(
      "UPDATE tarea SET Finalizada=1"
      ." WHERE idTarea=?");
    $sentencia->execute(array($tarea['id']));
    return $sentencia->rowCount();
  }

}
?>
