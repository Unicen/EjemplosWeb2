<?php
// En versiones de PHP anteriores a 4.1.0, $HTTP_POST_FILES debe utilizarse en lugar
// de $_FILES.

$uploaddir = '/Applications/XAMPP/xamppfiles/htdocs/web2/upload/';

foreach ($_FILES["userfiles"]["error"] as $key => $error) {
    if ($error == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES["userfiles"]["tmp_name"][$key];
        $name = $_FILES["userfiles"]["name"][$key];
        $uploadfile = $uploaddir . $name;
        move_uploaded_file($tmp_name, $uploadfile);
    }
    echo "Resultado archivo " . $key . ": ";
    switch($error){
      case UPLOAD_ERR_OK : echo "OK";
              break;
      case UPLOAD_ERR_FORM_SIZE : echo "File size no soportado";
    }
    echo "<br />";
}
?>
